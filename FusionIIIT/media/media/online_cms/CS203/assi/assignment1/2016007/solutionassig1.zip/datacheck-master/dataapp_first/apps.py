from django.apps import AppConfig


class DataappFirstConfig(AppConfig):
    name = 'dataapp_first'
