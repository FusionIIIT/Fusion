from django.apps import AppConfig


class CounsellingCellConfig(AppConfig):
    name = 'applications.counselling_cell'
