from django.apps import AppConfig


class FileTrackingConfig(AppConfig):
    name = 'applications.filetracking'
