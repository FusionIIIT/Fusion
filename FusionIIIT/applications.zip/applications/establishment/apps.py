from django.apps import AppConfig


class EstablishmentConfig(AppConfig):
    name = 'applications.establishment'
