from django.apps import AppConfig


class EisConfig(AppConfig):
    name = 'applications.eis'
