$(document).ready(function() {
    $('.ui.checkbox')
        .checkbox()
    ;
});