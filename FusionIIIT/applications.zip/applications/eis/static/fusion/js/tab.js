$(document).ready(function() {
    $('.menu .item')
        .tab()
    }
);