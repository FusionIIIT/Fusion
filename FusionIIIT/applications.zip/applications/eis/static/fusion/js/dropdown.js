$(document ).ready(function() {
    $('.dropdown')
        .dropdown({
            on: 'hover'
        })
    }
);