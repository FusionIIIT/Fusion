from django.apps import AppConfig


class FinanceAccountsConfig(AppConfig):
    name = 'applications.finance_accounts'
