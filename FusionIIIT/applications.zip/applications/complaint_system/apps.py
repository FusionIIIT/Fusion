from django.apps import AppConfig


class ComplaintSystemConfig(AppConfig):
    name = 'applications.complaint_system'
