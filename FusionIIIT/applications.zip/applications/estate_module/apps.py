from django.apps import AppConfig


class EstateModuleConfig(AppConfig):
    name = 'applications.estate_module'
