from django.apps import AppConfig


class GlobalsConfig(AppConfig):
    name = 'applications.globals'
