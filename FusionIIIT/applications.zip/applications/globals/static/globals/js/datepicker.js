$(document).ready(function(){$('.rangestart').calendar({
    type: 'date',
});
$('.rangeend').calendar({
    type: 'date',
});

$(".date.calendar").calendar({ type: "date" });
});
