from django.apps import AppConfig


class AcademicInformationConfig(AppConfig):
    name = 'applications.academic_information'
