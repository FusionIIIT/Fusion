from django.conf.urls import url

from . import views

urlpatterns = [

    # url(r'^courses',views.course_api,name='course-get-api'),

    # url(r'^curriculum',views.curriculum_api,name='curriculum-get-api'),

    # url(r'^curriculum_instructor',views.curriculum_instructor_api,name='curriculum_instructor-get-api'),

    # url(r'^students',views.student_api,name='student-get-api'),

    # url(r'^meeting',views.meeting_api,name='meeting-get-api'),

    url(r'^calendar',views.ListCalendarView.as_view(),name='calendar-get-api'),
    url(r'^update-calendar',views.update_calendar,name='calendar-update-api'),

    # url(r'^holiday',views.holiday_api,name='holiday-get-api'),

    # url(r'^timetable',views.timetable_api,name='timetable-get-api'),

    # url(r'^exam_timetable',views.exam_timetable_api,name='exam_timetable-get-api'),

    # url(r'^student_attendance',views.student_attendance_api,name='student_attendance-get-api'),

    # url(r'^grades',views.grades_api,name='grades-get-api'),

    # url(r'^spi',views.spi_api,name='spi-get-api')
]
