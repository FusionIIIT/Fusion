from django.apps import AppConfig


class AcademicProceduresConfig(AppConfig):
    name = 'applications.academic_procedures'
