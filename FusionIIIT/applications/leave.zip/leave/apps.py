from django.apps import AppConfig


class LeaveConfig(AppConfig):
    name = 'applications.leave'
