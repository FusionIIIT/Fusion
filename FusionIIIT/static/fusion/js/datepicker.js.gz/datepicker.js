$('#rangestart').calendar({
    type: 'date',
    endCalendar: $('#rangeend')
});
$('#rangeend').calendar({
    type: 'date',
    startCalendar: $('#rangestart')
});

$('#rangestart1').calendar({
    type: 'date',
    endCalendar: $('#rangeend1')
});
$('#rangeend1').calendar({
    type: 'date',
    startCalendar: $('#rangestart1')
});

$('#rangestart2').calendar({
    type: 'date',
    endCalendar: $('#rangeend2')
});
$('#rangeend2').calendar({
    type: 'date',
    startCalendar: $('#rangestart2')
});

$('#rangestart3').calendar({
    type: 'date',
    endCalendar: $('#rangeend3')
});
$('#rangeend3').calendar({
    type: 'date',
    startCalendar: $('#rangestart3')
});
